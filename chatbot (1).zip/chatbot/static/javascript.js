document.addEventListener("DOMContentLoaded", () => {
    const generateBtn = document.getElementById("generateBtn");
    const themeInput = document.getElementById("themeInput");
    const paletteResponse = document.getElementById("paletteResponse");

    generateBtn.addEventListener("click", async () => {
        const userTheme = themeInput.value.trim();
        if (!userTheme) {
            paletteResponse.innerHTML = "<em>Please enter a painting theme.</em>";
            return;
        }

        paletteResponse.innerHTML = "Generating color palette...";

        const strictPrompt = `You are a color palette expert for painting concepts. Only respond to queries about painting themes. If the user asks something unrelated, politely say you can only assist with painting palettes.\nTheme: ${userTheme}`;

        try {
            const res = await fetch("/get_palette", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ theme: strictPrompt })
            });

            const data = await res.json();
            paletteResponse.innerHTML = formatPalette(data.reply);
        } catch (error) {
            paletteResponse.innerHTML = "Error fetching color palette.";
        }
    });

    function formatPalette(replyText) {
        const lines = replyText.trim().split("\n");
        return lines.map(line => {
            const match = line.match(/#([0-9A-Fa-f]{6})/);
            if (match) {
                const hex = `#${match[1]}`;
                return `<div><span class="swatch" style="background:${hex}"></span>${line}</div>`;
            }
            return `<div>${line}</div>`;
        }).join("");
    }
});
