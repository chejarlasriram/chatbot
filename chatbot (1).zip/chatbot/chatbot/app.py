from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

API_KEY = 'YOUR_API_KEY'
BASE_URL = 'https://api.cricapi.com/v1'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/live-matches')
def live_matches():
    response = requests.get(f"{BASE_URL}/currentMatches", params={"apikey": API_KEY})
    return jsonify(response.json())

@app.route('/upcoming-matches')
def upcoming_matches():
    response = requests.get(f"{BASE_URL}/matches", params={"apikey": API_KEY})
    return jsonify(response.json())

@app.route('/match-stats/<match_id>')
def match_stats(match_id):
    response = requests.get(f"{BASE_URL}/match_scorecard", params={"apikey": API_KEY, "id": match_id})
    return jsonify(response.json())

if __name__ == '__main__':
    app.run(debug=True)
