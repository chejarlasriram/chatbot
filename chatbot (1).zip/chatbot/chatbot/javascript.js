async function loadLiveMatches() {
    const res = await fetch('/live-matches');
    const data = await res.json();
    const container = document.getElementById('live-matches');
    container.innerHTML = '';
    data.data.forEach(match => {
        container.innerHTML += `<p>${match.name} - ${match.status}</p>`;
    });
}

async function loadUpcomingMatches() {
    const res = await fetch('/upcoming-matches');
    const data = await res.json();
    const container = document.getElementById('upcoming-matches');
    container.innerHTML = '';
    data.data.forEach(match => {
        container.innerHTML += `<p>${match.name} - ${match.date}</p>`;
    });
}

window.onload = () => {
    loadLiveMatches();
    loadUpcomingMatches();
};
