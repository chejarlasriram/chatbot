from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

GEMINI_API_KEY = "AIzaSyD60i53OAzUYQAMjF_d4z-5-B7330ECm5Q"
GEMINI_BASE_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_palette", methods=["POST"])
def get_palette():
    try:
        user_theme = request.json.get("theme")
        prompt = (
            "You are a color palette expert. Given a painting theme, respond with 5 complementary colors including color names and their HEX codes. "
            f"Theme: {user_theme}"
        )

        headers = {"Content-Type": "application/json"}
        data = {
            "contents": [
                {
                    "parts": [{"text": prompt}]
                }
            ]
        }

        response = requests.post(GEMINI_BASE_URL, headers=headers, json=data)
        response.raise_for_status()
        gemini_reply = response.json()["candidates"][0]["content"]["parts"][0]["text"]
        return jsonify({"reply": gemini_reply})

    except Exception as e:
        return jsonify({"reply": f"Error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
